# WooCommerce Manually Add Review

This plugin adds an admin screen to allow reviews to manually be added to products.

In some cases the review section on the admin product page does not work (e.g. when you enable the Gutenberg editor). Add this plugin to enable this feature again.
